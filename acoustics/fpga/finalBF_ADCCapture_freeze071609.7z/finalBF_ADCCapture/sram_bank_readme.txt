The following files were generated for 'sram_bank' in directory 
/afs/unity.ncsu.edu/users/b/bmhendri/finalBF_ADCCapture:

sram_bank.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

sram_bank.vhd:
   VHDL wrapper file provided to support functional simulation. This
   file contains simulation model customization data that is passed to
   a parameterized simulation model for the core.

sram_bank.vho:
   VHO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a VHDL design.

sram_bank.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

sram_bank.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

sram_bank.asy:
   Graphical symbol information file. Used by the ISE tools and some
   third party tools to create a symbol representing the core.

sram_bank.sym:
   Please see the core data sheet.

sram_bank_xmdf.tcl:
   ISE Project Navigator interface file. ISE uses this file to determine
   how the files output by CORE Generator for the core can be integrated
   into your ISE project.

sram_bank.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

sram_bank_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

sram_bank_readme.txt:
   Text file indicating the files generated and how they are used.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

